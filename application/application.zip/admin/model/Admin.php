<?php
/**
 * Created by PhpStorm.
 * User: mr_z
 * Date: 2017/8/28
 * Time: 下午5:37
 */
namespace app\admin\model;

use think\Model;

class Admin extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $table = 'admin';
    
    
  
    
}